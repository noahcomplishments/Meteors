"By Mark Schneider"
import pygame, math
pygame.init()
WIDTH = 900
HEIGHT = 900
class Meteor():
    def __init__(self, screen, x, y, vel_x, vel_y, size):
        """This class represents a meteor"""
        self.size = size
        if self.size == "L":
            self.radius = 40
            self.image = pygame.image.load('largerasteroid.png')
        if self.size == "M":
            self.radius = 20
            self.image = pygame.image.load('largeasteroid.png')
        if self.size == "S":
            self.radius = 10
            self.image = pygame.image.load('mediumasteroid.png')

        self.x = x  
        self.y = y
        self.vel_x = vel_x
        self.vel_y = vel_y
        self.center = [self.x, self.y]
        self.screen = screen

    def update(self):
        self.x = ((self.x + self.vel_x) % (WIDTH + 40))
        self.y = ((self.y + self.vel_y) % (HEIGHT + 40))

        self.center = [self.x, self.y]

    def draw(self, screen):
        screen.blit(self.image, (self.x - self.radius, self.y - self.radius))
